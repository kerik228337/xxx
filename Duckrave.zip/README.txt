RU:
Данный драйвер работает только на Windows 11 22H2|23H2|24H2|25H2. Другие версии не поддерживаются в меру странных вещей, которые вытворяет этот драйвер.
ЗАПУСКАЙТЕ ЕГО ТОЛЬКО НА ВИРТУАЛЬНОЙ МАШИНЕ, действия которые делает драйвер весьма сомнительны и могут быть небезопасны, или вызвать BSOD.

Инструкция по запуску (опять же всё это внутри вм-ки):
1. Запустить cmd от имени админа, ввести следующие команды:
bcdedit /set testsigning on
bcdedit /set nointegritychecks on
bcdedit /debug on
2. Перекинуть драйвер в C:\drivers\Duckrave.sys (папку drivers создайте сами);
3. Ввести в командной строке от админа следующие команды:
sc create duckrave type= kernel binPath= C:\drivers\Duckrave.sys
sc start duckrave
4. Проверить запуск драйвера (логи в DbgView + аутпут команды sc);
5. Если всё хорошо, можете запускать таск через приложение "Duckrave.exe".

====================================================

EN:
This driver works only on Windows 11 22H2|23H2|24H2|25H2. Other versions are not supported due to some weird things this driver does.
START THIS DRIVER ONLY ON A VIRTUAL MACHINE, things the driver do are strange and can be harmful to your PC, sometimes straight up giving you a BSOD.

Launch instructions:
1. Launch elevated cmd, enter the following commands:
bcdedit /set testsigning on
bcdedit /set nointegritychecks on
bcdedit /debug on
2. Drop the driver into C:\drivers\Duckrave.sys (create drivers folder yourself);
3. In elevated cmd enter the following commands:
sc create duckrave type= kernel binPath= C:\drivers\Duckrave.sys
sc start duckrave
4. Check the driver startup (logs in DbgView + sc command output);
5. If everything's fine, you can start the challenge by launching "Duckrave.exe" file.


CREDIT:
https://www.shadertoy.com/view/lctGRB
https://www.pouet.net/prod.php?which=96542